#!/bin/bash
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
#apt-get update
#apt-get remove -y --force-yes com.firecore.spbootstrap
dpkg -i /usr/libexec/sp/bl.deb /usr/libexec/sp/sp.deb
apt-get remove -y --force-yes com.firecore.spbootstrap
exitcode=$?
echo "install_beigelist exited with" $exitcode
killall -9 AppleTV
exit $exitcode

